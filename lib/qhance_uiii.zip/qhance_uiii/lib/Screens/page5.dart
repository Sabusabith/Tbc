import 'package:flutter/material.dart';
import 'package:qhance_uiii/Screens/page6.dart';
import 'package:qhance_uiii/widgets/elevatedbutton.dart';
import 'package:qhance_uiii/widgets/textfield_widget.dart';

class page5 extends StatefulWidget {
  const page5({super.key});

  @override
  State<page5> createState() => _page5State();
}

class _page5State extends State<page5> {
  @override
  Widget build(BuildContext context) {
    Color myColor = Color(0xFF3EB489);
    return  SafeArea(
      child: Scaffold(
          body: Stack(children: [
          Container(
          width: 360,
          height: 850,
          color: myColor,
          child: Column(
          children: [
          Padding(
          padding: const EdgeInsets.all(8.0),
      child: Row(
      children: [
      SizedBox(
      height: 9,
      ),
      Icon(
      Icons.arrow_back,
      color: Colors.white,
      size: 27,
      ),
      SizedBox(
      width: 87,
      ),
      Text(
      ' Add Item',
      textAlign: TextAlign.center,
      style: TextStyle(
      color: Color.fromRGBO(255, 255, 255, 1),
      fontFamily: 'Inria Sans',
      fontSize: 25,
      letterSpacing: 0.15000000596046448,
      fontWeight: FontWeight.bold,
      height: 1.5 /*PERCENT not supported*/
      ),
      ),
      SizedBox(
      width: 87,
      ),
      Icon(
      Icons.logout,
      color: Colors.white,
      ),
      ],
      ),
      ),
      ],
      ),
      ),
      Positioned(
      //white Container
      top: 75,
      bottom: 0,
      child: Container(
      width: 360,
      height: 179,
      decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.only(
      topLeft: Radius.circular(35),
      topRight: Radius.circular(35),
      bottomLeft: Radius.circular(0),
      bottomRight: Radius.circular(0),
      ),
      ),
        child: Column(
          children: [
            SizedBox(height: 60,),
            texttfield(horizontal: 10, hintText: "Taskname", verticle: 18),
            SizedBox(height: 47,),
            Row(
              children: [
                SizedBox(width: 30,),
                Text("Evidence of compliance",style: TextStyle(fontSize: 18,fontWeight: FontWeight.w500),),
              ],
            ),
            SizedBox(height: 10,),
            texttfield(horizontal: 22, hintText: "What Evidence you need", verticle: 35),
            SizedBox(height: 230,),
            InkWell(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>page6()));
                },
                child: elevatedButton(text: 'submit', borderRadius: 10,)),
          ],
        ),
      ),
      )
          ]
          )
      
      ),
    );
  }
}
