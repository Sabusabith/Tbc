import 'package:flutter/material.dart';

class page8 extends StatefulWidget {
  const page8({super.key});

  @override
  State<page8> createState() => _page8State();
}

class _page8State extends State<page8> {
  @override
  Widget build(BuildContext context) {
    return  MaterialApp(
      home: Scaffold(
        body: ListView(children: [
          Column(
            children: [
              Container(
                width: 384,
                height: 800,
                clipBehavior: Clip.antiAlias,
                decoration: BoxDecoration(color: Colors.white),
                child: Stack(
                  children: [
                    Positioned(
                      left: 0,
                      top: 0,
                      child: Container(
                        width: 384,
                        height: 225,
                        decoration: BoxDecoration(color: Color(0xFF54BCA2)),
                      ),
                    ),
                    Positioned(
                      left: 0,
                      top: 67,
                      child: Container(
                        width: 384,
                        height: 733,
                        decoration: ShapeDecoration(
                          color: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(25),
                              topRight: Radius.circular(25),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 14,
                      top: 19,
                      child: Container(
                        width: 27.87,
                        height: 27,
                        padding: const EdgeInsets.only(
                          top: 6.75,
                          left: 4.65,
                          right: 5.81,
                          bottom: 6.75,
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [

                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 341,
                      top: 19,
                      child: Container(
                        width: 27,
                        height: 27,
                        padding: const EdgeInsets.all(2.25),
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [

                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 29,
                      top: 137,
                      child: Container(
                        width: 314,
                        height: 124,
                        decoration: ShapeDecoration(
                          color: Color(0xFFFFFBFB),
                          shape: RoundedRectangleBorder(
                            side: BorderSide(width: 2, color: Color(0xFF54BCA2)),
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 29,
                      top: 325,
                      child: Container(
                        width: 312,
                        height: 124,
                        decoration: ShapeDecoration(
                          color: Color(0xFFFFFCFC),
                          shape: RoundedRectangleBorder(
                            side: BorderSide(width: 2, color: Color(0xFF54BCA2)),
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 28,
                      top: 513,
                      child: Container(
                        width: 315,
                        height: 124,
                        decoration: ShapeDecoration(
                          color: Colors.white,
                          shape: RoundedRectangleBorder(
                            side: BorderSide(width: 2, color: Color(0xFF54BCA2)),
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 119,
                      top: 527,
                      child: Text(
                        'Not overcrowding the patients in \nthe Reception area',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 13,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w500,
                          height: 0,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 29,
                      top: 137,
                      child: Container(
                        width: 81,
                        height: 124,
                        decoration: ShapeDecoration(
                          color: Color(0xFF54BCA2),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(10),
                              bottomLeft: Radius.circular(10),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 42,
                      top: 198,
                      child: Text(
                        'End Date',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w400,
                          height: 0,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 37,
                      top: 164,
                      child: Text(
                        '10-12-2023',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w600,
                          height: 0,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 37,
                      top: 214,
                      child: Text(
                        '10-12-2023',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w600,
                          height: 0,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 29,
                      top: 325,
                      child: Container(
                        width: 81,
                        height: 124,
                        decoration: ShapeDecoration(
                          color: Color(0xFF54BCA2),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(10),
                              bottomLeft: Radius.circular(10),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 37,
                      top: 405,
                      child: Text(
                        '10-12-2023',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w600,
                          height: 0,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 42,
                      top: 198,
                      child: Text(
                        'End Date',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w400,
                          height: 0,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 42,
                      top: 389,
                      child: Text(
                        'End Date',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w400,
                          height: 0,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 37,
                      top: 355,
                      child: Text(
                        '10-12-2023',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w600,
                          height: 0,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 29,
                      top: 513,
                      child: Container(
                        width: 81,
                        height: 124,
                        decoration: ShapeDecoration(
                          color: Color(0xFF54BCA2),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(10),
                              bottomLeft: Radius.circular(10),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 37,
                      top: 594,
                      child: Text(
                        '10-12-2023',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w600,
                          height: 0,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 42,
                      top: 578,
                      child: Text(
                        'End Date',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w400,
                          height: 0,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 37,
                      top: 544,
                      child: Text(
                        '10-12-2023',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w600,
                          height: 0,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 42,
                      top: 528,
                      child: Text(
                        'Start Date',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w400,
                          height: 0,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 93,
                      top: 88,
                      child: Text(
                        'Primary health care name',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Color(0xFF54BCA2),
                          fontSize: 16,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w600,
                          height: 0,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 119,
                      top: 148,
                      child: Text(
                        'Completion of patients health \nrecords in HIS, Wasfaty program...',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 13,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w500,
                          height: 0,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 119,
                      top: 204,
                      child: Text(
                        'Assigned to ',
                        style: TextStyle(
                          color: Color(0xFFA29E9E),
                          fontSize: 11,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w500,
                          height: 0,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 117,
                      top: 389,
                      child: Text(
                        'Assigned to ',
                        style: TextStyle(
                          color: Color(0xFFA29E9E),
                          fontSize: 11,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w500,
                          height: 0,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 117,
                      top: 582,
                      child: Text(
                        'Assigned to ',
                        style: TextStyle(
                          color: Color(0xFFA29E9E),
                          fontSize: 11,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w500,
                          height: 0,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 119,
                      top: 221,
                      child: Text(
                        'Person name',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 13,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w500,
                          height: 0,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 117,
                      top: 406,
                      child: Text(
                        'Person name',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 13,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w500,
                          height: 0,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 117,
                      top: 599,
                      child: Text(
                        'Person name',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 13,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w500,
                          height: 0,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 119,
                      top: 339,
                      child: Text(
                        'Receving the patients and \ndirecting them to the TBC on ......',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 13,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w500,
                          height: 0,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 42,
                      top: 148,
                      child: Text(
                        'Start Date',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w400,
                          height: 0,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 42,
                      top: 339,
                      child: Text(
                        'Start Date',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w400,
                          height: 0,
                        ),
                      ),
                    ),
                    Positioned(
                      left: 76,
                      top: 18,
                      child: Text(
                        'Reception Activities',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w600,
                          height: 0,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          )
        ]),
      ),
    );
  }
}


