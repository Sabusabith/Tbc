import 'package:flutter/material.dart';
import 'package:qhance_uiii/Screens/page8.dart';


class page2 extends StatefulWidget {
  const page2({super.key});

  @override
  State<page2> createState() => _page2State();
}

class _page2State extends State<page2> {
  @override
  Widget build(BuildContext context) {
    Color myColor = Color(0xFF3EB489);
    return SafeArea(
        child: Scaffold(
      body: Stack(children: [
        Container(
          width: 360,
          height: 850,
          color: myColor,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  children: [
                    SizedBox(
                      height: 9,
                    ),
                    Icon(
                      Icons.arrow_back,
                      color: Colors.white,
                      size: 27,
                    ),
                    SizedBox(
                      width: 17,
                    ),
                    Text(
                      'Southern Zone Domains',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Color.fromRGBO(255, 255, 255, 1),
                          fontFamily: 'Inria Sans',
                          fontSize: 23,
                          letterSpacing: 0.15000000596046448,
                          fontWeight: FontWeight.w500,
                          height: 1.5 /*PERCENT not supported*/
                          ),
                    ),
                    SizedBox(
                      width: 18,
                    ),
                    Icon(
                      Icons.logout,
                      color: Colors.white,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        Positioned(
            //white Container
            top: 75,
            bottom: 0,
            child: Container(
              width: 360,
              height: 179,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(35),
                  topRight: Radius.circular(35),
                  bottomLeft: Radius.circular(0),
                  bottomRight: Radius.circular(0),
                ),
              ),
              child: Column(
                children: [
                  SizedBox(
                    height: 55,
                  ),
                  Row(
                    children: [
                      SizedBox(
                        width: 27,
                      ),
                      Container(
                          //indigoaccent
                          width: 150,
                          height: 150,
                          decoration: BoxDecoration(
                              border: Border.all(
                                color: myColor,
                                width: 3,
                              ),
                              borderRadius: BorderRadius.circular(10),
                              boxShadow: [
                                BoxShadow(
                                    color: Color.fromRGBO(0, 0, 0, 0.25),
                                    offset: Offset(0, 4),
                                    blurRadius: 2)
                              ],
                              color: Colors.white),
                      child: Column(
                        children: [
                          SizedBox(
                            height: 10,
                          ),
                          Image.asset("assets/meeting.png",
                          cacheWidth: 70,
                          cacheHeight: 70,
                          ),
                        Text('TBC Huddle', textAlign: TextAlign.center, style: TextStyle(
                            color: myColor,
                            fontFamily: 'Inter',
                            fontSize: 19,
                            letterSpacing: 0 /*percentages not used in flutter. defaulting to zero*/,
                            fontWeight: FontWeight.w500,
                            height: 1
                        ),),
                          Text("Meeting",textAlign: TextAlign.center, style: TextStyle(
                              color: myColor,
                              fontFamily: 'Inter',
                              fontSize: 17,
                              letterSpacing: 0 /*percentages not used in flutter. defaulting to zero*/,
                              fontWeight: FontWeight.w500,
                              height: 1
                          ),)
                        ],
                      ),
                      ),
                      SizedBox(
                        width: 17,
                      ),
                      InkWell(onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>page8()));
                      },
                        child: Container(
                            width: 150,
                            height: 150,
                            decoration: BoxDecoration(
                                border: Border.all(color: myColor, width: 3),
                                borderRadius: BorderRadius.circular(10),
                                boxShadow: [
                                  BoxShadow(
                                      color: Color.fromRGBO(0, 0, 0, 0.25),
                                      offset: Offset(0, 4),
                                      blurRadius: 2)
                                ],
                                color: Colors.white),
                          child: Column(
                            children: [
                              Image.asset("assets/reception.png",
                              cacheHeight: 90,
                                cacheWidth: 90,

                              ),
                              Text("Reception",textAlign: TextAlign.center, style: TextStyle(
                                  color: myColor,
                                  fontFamily: 'Inter',
                                  fontSize: 21,
                                  letterSpacing: 0 /*percentages not used in flutter. defaulting to zero*/,
                                  fontWeight: FontWeight.w500,
                                  height: 1
                              ),


                              ),
                            ],
                          ),





                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  Row(
                    children: [
                      SizedBox(
                        width: 27,
                      ),
                      Container(
                          width: 150,
                          height: 150,
                          decoration: BoxDecoration(
                              border: Border.all(color: myColor, width: 3),
                              borderRadius: BorderRadius.circular(10),
                              boxShadow: [
                                BoxShadow(
                                    color: Color.fromRGBO(0, 0, 0, 0.25),
                                    offset: Offset(0, 4),
                                    blurRadius: 2)
                              ],
                              color: Colors.white),
                      child: Column(
                        children: [
                          Image.asset("assets/patient.png",
                          cacheWidth: 70,
                            cacheHeight: 70,
                          ),
                          Text("Patients Rights",textAlign: TextAlign.center, style: TextStyle(
                              color: myColor,
                              fontFamily: 'Inter',
                              fontSize: 19,
                              letterSpacing: 0 /*percentages not used in flutter. defaulting to zero*/,
                              fontWeight: FontWeight.w500,
                              height: 1
                          )),
                          Text("&",textAlign: TextAlign.center, style: TextStyle(
                            color: myColor,
                            fontFamily: 'Inter',
                            fontSize: 15,
                            letterSpacing: 0 /*percentages not used in flutter. defaulting to zero*/,
                            fontWeight: FontWeight.bold,
                            height: 1
                          )),
                          Text("Responsibilty",textAlign: TextAlign.center, style: TextStyle(
                              color: myColor,
                              fontFamily: 'Inter',
                              fontSize: 18,
                              letterSpacing: 0 /*percentages not used in flutter. defaulting to zero*/,
                              fontWeight: FontWeight.w500,
                              height: 1
                          ))
                        ],
                      ),
                      
                      
                      ),
                      SizedBox(
                        width: 17,
                      ),
                      Container(
                          width: 150,
                          height: 150,
                          decoration: BoxDecoration(
                              border: Border.all(color: myColor, width: 3),
                              borderRadius: BorderRadius.circular(10),
                              boxShadow: [
                                BoxShadow(
                                    color: Color.fromRGBO(0, 0, 0, 0.25),
                                    offset: Offset(0, 4),
                                    blurRadius: 2)
                              ],
                              color: Colors.white),

                       child:
                       Column(
                         children:[
                       Image.asset("assets/coodernates.png",cacheHeight: 80,cacheWidth: 80,),
                           Text("Case",textAlign: TextAlign.center, style: TextStyle(
                               color: myColor,
                               fontFamily: 'Inter',
                               fontSize: 20,
                               letterSpacing: 0 /*percentages not used in flutter. defaulting to zero*/,
                               fontWeight: FontWeight.w500,
                               height: 1
                           )),
                           Text("Coordinator",textAlign: TextAlign.center, style: TextStyle(
                               color: myColor,
                               fontFamily: 'Inter',
                               fontSize: 19,
                               letterSpacing: 0 /*percentages not used in flutter. defaulting to zero*/,
                               fontWeight: FontWeight.w500,
                               height: 1
                           )),
]
                       )
                      )
                    ],
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  Row(
                    children: [
                      SizedBox(
                        width: 27,
                      ),
                      Container(
                          width: 150,
                          height: 150,
                          decoration: BoxDecoration(
                              border: Border.all(color: myColor, width: 3),
                              borderRadius: BorderRadius.circular(10),
                              boxShadow: [
                                BoxShadow(
                                    color: Color.fromRGBO(0, 0, 0, 0.25),
                                    offset: Offset(0, 4),
                                    blurRadius: 2)
                              ],
                              color: Colors.white),
                           child: Column(
                             children: [
                               Image.asset("assets/health.png",cacheWidth: 70,cacheHeight: 70,),
                               Text("Health",textAlign: TextAlign.center, style: TextStyle(
                                   color: myColor,
                                   fontFamily: 'Inter',
                                   fontSize: 24,
                                   letterSpacing: 0 /*percentages not used in flutter. defaulting to zero*/,
                                   fontWeight: FontWeight.w500,
                                   height: 1
                               )),
                               Text("Coach",textAlign: TextAlign.center, style: TextStyle(
                                   color: myColor,
                                   fontFamily: 'Inter',
                                   fontSize: 20,
                                   letterSpacing: 0 /*percentages not used in flutter. defaulting to zero*/,
                                   fontWeight: FontWeight.w500,
                                   height: 1
                               )),

                             ],
                           ),
                      ),
                      SizedBox(
                        width: 17,
                      ),
                      Container(
                          width: 150,
                          height: 150,
                          decoration: BoxDecoration(
                              border: Border.all(color: myColor, width: 3),
                              borderRadius: BorderRadius.circular(10),
                              boxShadow: [
                                BoxShadow(
                                    color: Color.fromRGBO(0, 0, 0, 0.25),
                                    offset: Offset(0, 4),
                                    blurRadius: 2)
                              ],
                              color: Colors.white),
                      
                      child: Column(
                        children: [
                          Image.asset("assets/nurse.png",cacheHeight: 70,cacheWidth: 70,),
                          SizedBox(height: 10,),
                          Text("Nursing",textAlign: TextAlign.center, style: TextStyle(
                              color: myColor,
                              fontFamily: 'Inter',
                              fontSize: 24,
                              letterSpacing: 0 /*percentages not used in flutter. defaulting to zero*/,
                              fontWeight: FontWeight.w500,
                              height: 1
                          ))
                        ],
                      ),
                      )
                    ],
                  )
                ],
              ),
            )),
      ]),
    ));
  }
}
