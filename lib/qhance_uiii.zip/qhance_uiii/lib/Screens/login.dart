import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:qhance_uiii/Screens/page1.dart';
import 'dart:math' as math;

// Your code here

class login extends StatefulWidget {
  const login({super.key});

  @override
  State<login> createState() => _loginState();
}

class _loginState extends State<login> {
  TextEditingController username = TextEditingController();

  @override
  Widget build(BuildContext context) {
    Color myColor = Color(0xFF3EB489);
    return SafeArea(
      child: Scaffold(
        body: Stack(
          children: [
            // Background Container
            Container(
              width: 360,
              height: 850,
              color: myColor,

              child: Column(
                children: [
                  SizedBox(
                    height: 140,
                  ),
                  Text(
                    'Sign In',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Color.fromRGBO(255, 255, 255, 1),
                        fontFamily: 'gordita',
                        fontSize: 40,
                        letterSpacing: 0.15000000596046448,
                        fontWeight: FontWeight.bold,
                        height: 1.5 /*PERCENT not supported*/
                        ),
                  ),
                ],
              ),
              // Background color
            ),

            // Foreground Container
            Positioned(
              //white Container
              top: 210,
              bottom: 0,
              child: Container(
                width: 360,
                height: 179,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(30),
                    topRight: Radius.circular(30),
                    bottomLeft: Radius.circular(0),
                    bottomRight: Radius.circular(0),
                  ),
                ),
                child: Column(
                  //textfield and text etc..........
                  children: [
                    SizedBox(
                      height: 68,
                    ),
                    Row(
                      children: [
                        SizedBox(
                          width: 33,
                        ),
                        Text(
                          'Email Adress',
                          textAlign: TextAlign.start,
                          style: TextStyle(
                              color: Colors.black,
                              fontFamily: 'Inter',
                              fontSize: 17,
                              letterSpacing:
                                  0 /*percentages not used in flutter. defaulting to zero*/,
                              fontWeight: FontWeight.normal,
                              height: 1),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.all(17.0),
                      child: TextField(
                        decoration: InputDecoration(
                            filled: true,
                            fillColor: Colors.grey.shade200,
                            // Set the desired background color
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                  width: 1, color: Colors.grey.shade300),
                              borderRadius: BorderRadius.circular(15.0),
                            ),
                            contentPadding: EdgeInsets.symmetric(
                                horizontal: 18, vertical: 18),
                            hintText: "Enter your Id",
                            hintStyle: TextStyle(
                                fontStyle: FontStyle.italic,
                                fontSize: 15,
                                fontWeight: FontWeight.w400)),
                      ),
                    ),
                    Row(
                      children: [
                        SizedBox(
                          width: 37,
                        ),
                        Text(
                          "Password",
                          style: TextStyle(
                              color: Colors.black87,
                              fontFamily: 'Inter',
                              fontSize: 17,
                              letterSpacing:
                                  0 /*percentages not used in flutter. defaulting to zero*/,
                              fontWeight: FontWeight.normal,
                              height: 1),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.all(17.0),
                      child: TextField(
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: Colors.grey.shade200,
                          // Set the desired background color
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                width: 1, color: Colors.grey.shade300),
                            borderRadius: BorderRadius.circular(15.0),
                          ),
                          contentPadding: EdgeInsets.symmetric(
                              horizontal: 18, vertical: 18),
                          hintText: "Enter your Password",
                          hintStyle: TextStyle(
                              fontStyle: FontStyle.italic,
                              fontSize: 15,
                              fontWeight: FontWeight.w400),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15),
                            ),
                            fixedSize: Size(230, 60),
                            primary: myColor,
                            onPrimary: Colors.white),
                        onPressed: () {
                          Navigator.push(context,
                              MaterialPageRoute(builder: (context) => page1()));
                        },
                        child: Text(
                          "Login",
                          style: TextStyle(fontSize: 19),
                        )),
                    SizedBox(
                      height: 14,
                    ),
                    Row(
                      children: [
                        SizedBox(
                          width: 80,
                        ),
                        Transform.rotate(
                          angle: -0.007656779584953405 * (math.pi / 180),
                          child: Container(
                            width: 75,
                            child: Divider(
                                color: Color.fromRGBO(0, 0, 0, 1),
                                thickness: 1),
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Text(
                          "Or",
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.w500),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Transform.rotate(
                          angle: -0.007656779584953405 * (math.pi / 180),
                          child: Container(
                            width: 75,
                            child: Divider(
                                color: Color.fromRGBO(0, 0, 0, 1),
                                thickness: 1),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 19,),
                    Row(
                      children: [
                        SizedBox(width: 128),
                        Container(
                          height: 35,
                          width: 35,
                          decoration: BoxDecoration(
                            borderRadius : BorderRadius.only(
                              topLeft: Radius.circular(8),
                              topRight: Radius.circular(8),
                              bottomLeft: Radius.circular(8),
                              bottomRight: Radius.circular(8),
                            ),
                            border : Border.all(
                              color: Colors.white,
                              width: 1,
                            ),
                          ),
                          child: Image.asset("assets/google.png"),

                        ),
                        SizedBox(width: 26,),
                        Container(
                          height: 35,
                          width: 35,
                          decoration: BoxDecoration(
                            borderRadius : BorderRadius.only(
                              topLeft: Radius.circular(8),
                              topRight: Radius.circular(8),
                              bottomLeft: Radius.circular(8),
                              bottomRight: Radius.circular(8),
                            ),
                            border : Border.all(
                              color: Colors.white,
                              width: 1,
                            ),
                          ),
                    child:  Image.asset("assets/facebook.png"),
                        ),

                      ],
                    )



                  ],
                ),
              ),
            ),
            // Foreground color
          ],
        ),
      ),
    );
  }
}
