import 'package:flutter/material.dart';

class page7 extends StatefulWidget {
  page7({Key? key}) : super(key: key);

  @override
  State<page7> createState() => _page7State();
}

class _page7State extends State<page7> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: ListView(
          children: [
        Column(
        children: [
        Container(
        width: 384,
          height: 800,
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(color: Colors.white),
          child: Stack(
            children: [
              Positioned(
                left: 0,
                top: 0,
                child: Container(
                  width: 384,
                  height: 208,
                  decoration: ShapeDecoration(
                    color: Color(0xFF54BCA2),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(50),
                        bottomRight: Radius.circular(50),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 75,
                top: 38,
                child: Text(
                  'Primary Health Care',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w600,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 342,
                top: 38,
                child: Container(
                  width: 27,
                  height: 27,
                  padding: const EdgeInsets.all(2.25),
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [

                    ],
                  ),
                ),
              ),
              Positioned(
                left: 14,
                top: 38,
                child: Container(
                  width: 27.87,
                  height: 27,
                  padding: const EdgeInsets.only(
                    top: 6.75,
                    left: 4.65,
                    right: 5.81,
                    bottom: 6.75,
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [

                    ],
                  ),
                ),
              ),
              Positioned(
                left: 42,
                top: 166,
                child: Container(
                  width: 301,
                  height: 86,
                  decoration: ShapeDecoration(
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                      side: BorderSide(width: 3, color: Color(0xFF54BCA2)),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    shadows: [
                      BoxShadow(
                        color: Color(0x38000000),
                        blurRadius: 2,
                        offset: Offset(0, 2),
                        spreadRadius: 0,
                      )
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 57,
                top: 195,
                child: Text(
                  'Primary Health Care Name ',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0xFFA29E9E),
                    fontSize: 14,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w500,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 57,
                top: 176,
                child: Text(
                  'Health Zone Name ',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 16,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w700,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 268,
                top: 173,
                child: Text(
                  'Care Code',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0xFF818080),
                    fontSize: 12,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w600,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 22,
                top: 282,
                child: Text(
                  'Team Members',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 20,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w600,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 21,
                top: 336,
                child: Container(
                  width: 327,
                  height: 78,
                  decoration: ShapeDecoration(
                    color: Color(0xFFFFFBFB),
                    shape: RoundedRectangleBorder(
                      side: BorderSide(width: 2, color: Color(0xFF54BCA2)),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    shadows: [
                      BoxShadow(
                        color: Color(0x3F000000),
                        blurRadius: 4,
                        offset: Offset(0, 4),
                        spreadRadius: 0,
                      )
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 21,
                top: 444,
                child: Container(
                  width: 327,
                  height: 78,
                  decoration: ShapeDecoration(
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                      side: BorderSide(width: 2, color: Color(0xFF54BCA2)),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    shadows: [
                      BoxShadow(
                        color: Color(0x3F000000),
                        blurRadius: 4,
                        offset: Offset(0, 4),
                        spreadRadius: 0,
                      )
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 305,
                top: 453,
                child: Text(
                  'Role',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0xFFA29E9E),
                    fontSize: 12,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w500,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 110,
                top: 496,
                child: Text(
                  '+91 9995559990',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 13,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w600,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 109,
                top: 470,
                child: Text(
                  'Speciality',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0xFFA29E9E),
                    fontSize: 13,
                    fontStyle: FontStyle.italic,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w400,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 109,
                top: 453,
                child: Text(
                  'Person name',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 15,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w700,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 30,
                top: 453,
                child: Container(
                  width: 60,
                  height: 60,
                  decoration: ShapeDecoration(
                    color: Color(0xFFD9D9D9),
                    shape: OvalBorder(),
                  ),
                ),
              ),
              Positioned(
                left: 22,
                top: 552,
                child: Container(
                  width: 327,
                  height: 78,
                  decoration: ShapeDecoration(
                    color: Color(0xFFFFFDFD),
                    shape: RoundedRectangleBorder(
                      side: BorderSide(width: 2, color: Color(0xFF54BCA2)),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    shadows: [
                      BoxShadow(
                        color: Color(0x3F000000),
                        blurRadius: 4,
                        offset: Offset(0, 4),
                        spreadRadius: 0,
                      )
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 305,
                top: 561,
                child: Text(
                  'Role',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0xFFA29E9E),
                    fontSize: 12,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w500,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 110,
                top: 605,
                child: Text(
                  '+91 9995559990',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 13,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w600,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 109,
                top: 579,
                child: Text(
                  'Speciality',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0xFFA29E9E),
                    fontSize: 13,
                    fontStyle: FontStyle.italic,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w400,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 109,
                top: 561,
                child: Text(
                  'Person name',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 15,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w700,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 30,
                top: 561,
                child: Container(
                  width: 60,
                  height: 60,
                  decoration: ShapeDecoration(
                    color: Color(0xFFD9D9D9),
                    shape: OvalBorder(),
                  ),
                ),
              ),
              Positioned(
                left: 21,
                top: 660,
                child: Container(
                  width: 327,
                  height: 78,
                  decoration: ShapeDecoration(
                    color: Color(0xFFFCF8F8),
                    shape: RoundedRectangleBorder(
                      side: BorderSide(width: 2, color: Color(0xFF54BCA2)),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    shadows: [
                      BoxShadow(
                        color: Color(0x3F000000),
                        blurRadius: 4,
                        offset: Offset(0, 4),
                        spreadRadius: 0,
                      )
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 305,
                top: 669,
                child: Text(
                  'Role',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0xFFA29E9E),
                    fontSize: 12,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w500,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 110,
                top: 713,
                child: Text(
                  '+91 9995559990',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 13,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w600,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 109,
                top: 687,
                child: Text(
                  'Speciality',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0xFFA29E9E),
                    fontSize: 13,
                    fontStyle: FontStyle.italic,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w400,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 109,
                top: 669,
                child: Text(
                  'Person name',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 15,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w700,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 30,
                top: 669,
                child: Container(
                  width: 60,
                  height: 60,
                  decoration: ShapeDecoration(
                    color: Color(0xFFD9D9D9),
                    shape: OvalBorder(),
                  ),
                ),
              ),
              Positioned(
                left: 30,
                top: 345,
                child: Container(
                  width: 60,
                  height: 60,
                  decoration: ShapeDecoration(
                    color: Color(0xFFD9D9D9),
                    shape: OvalBorder(),
                  ),
                ),
              ),
              Positioned(
                left: 109,
                top: 345,
                child: Text(
                  'Person name',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 15,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w700,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 109,
                top: 363,
                child: Text(
                  'Speciality',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0xFFA29E9E),
                    fontSize: 13,
                    fontStyle: FontStyle.italic,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w400,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 110,
                top: 389,
                child: Text(
                  '+91 9995559990',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 13,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w600,
                    height: 0,
                  ),
                ),
              ),
              Positioned(
                left: 305,
                top: 345,
                child: Text(
                  'Role',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0xFFA29E9E),
                    fontSize: 12,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w500,
                    height: 0,
                  ),
                ),
              ),
            ],
          ),
        ),
        ],
      )
        ]),
      ),
    );
  }
}
