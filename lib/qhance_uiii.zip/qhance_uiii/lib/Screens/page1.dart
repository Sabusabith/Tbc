import 'package:flutter/material.dart';
import 'package:qhance_uiii/Screens/page2.dart';
import 'package:qhance_uiii/Screens/page3.dart';
import 'package:qhance_uiii/Screens/page6.dart';
import 'package:google_fonts/google_fonts.dart';

class page1 extends StatefulWidget {
  const page1({super.key});

  @override
  State<page1> createState() => _page1State();
}

class _page1State extends State<page1> {
  @override
  Widget build(BuildContext context) {
    Color myColor = Color(0xFF3EB489);
    return SafeArea(
        child: Scaffold(
            body: SingleChildScrollView(
                child: Container(
                    width: 500,
                    height: 900,
                    color: Colors.white,
                    child: Column(
                      children: [
                        Container(
                          width: 375,
                          height: 200,
                          decoration: BoxDecoration(
                            color: myColor,
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(0),
                              topRight: Radius.circular(0),
                              bottomLeft: Radius.circular(110),
                              bottomRight: Radius.circular(110),
                            ),
                          ),
                          child: Container(
                            width: 35,
                            height: 27,
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Stack(children: <Widget>[
                                Column(
                                  children: [
                                    Row(
                                      children: [
                                        Positioned(
                                            top: 2.25,
                                            left: 4.375,
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: Icon(
                                                Icons.menu,
                                                color: Colors.white,
                                                size: 34,
                                              ),
                                            )),
                                        SizedBox(
                                          width: 260,
                                        ),
                                        Icon(
                                          Icons.logout,
                                          color: Colors.white,
                                          size: 27,
                                        )
                                      ],
                                    ),
                                    SizedBox(
                                      height: 40,
                                    ),
                                    Text(
                                      'Zones',
                                      textAlign: TextAlign.center,
                                      style:GoogleFonts.gorditas(
                                          textStyle: TextStyle(
                                            color: Color.fromRGBO(255, 255, 255, 1),
                                            fontSize: 36,
                                            letterSpacing: 0.15000000596046448,
                                            fontWeight: FontWeight.w500,
                                            height: 1.5,),
                                      )
                                    )
                                  ],
                                ),
                              ]),
                            ),
                          ),
                        ),
                        Column(
                          children: [
                            SizedBox(
                              height: 30,
                            ),
                            Row(
                              children: [
                                SizedBox(
                                  width: 14,
                                ),
                                InkWell(
                                  onTap: (){
                                    Navigator.push(context, MaterialPageRoute(builder: (context)=>page2()));
                                  },
                                  child: Container(
                                    height: 160,
                                    width: 160,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        border:
                                            Border.all(color: myColor, width: 2)),
                                    child: Column(
                                      children: [
                                        SizedBox(height: 35,),
                                        Text('Southern', textAlign: TextAlign.center, style: TextStyle(
                                            color: myColor,
                                            fontFamily: 'Russo One',
                                            fontSize: 24,
                                            letterSpacing: 0.15000000596046448,
                                            fontWeight: FontWeight.w500,
                                            height: 1.5 /*PERCENT not supported*/
                                        ),),
                                    Text('Zone', textAlign: TextAlign.center, style: TextStyle(
                                        color: myColor,
                                        fontFamily: 'Russo One',
                                        fontSize: 20,
                                        letterSpacing: 0.15000000596046448,
                                        fontWeight: FontWeight.w500,
                                        height: 1.5 /*PERCENT not supported*/
                                    ),)
                                      ],
                                    ),



                                  ),
                                ),
                                SizedBox(
                                  width: 15,
                                ),
                                Container(
                                    height: 160,
                                    width: 160,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      border:
                                          Border.all(color: myColor, width: 2),
                                    ),
                                child: Column(
                                  children: [
                                    SizedBox(height: 35,),
                                    Text('Northern', textAlign: TextAlign.center, style: TextStyle(
                                        color: myColor,
                                        fontFamily: 'Russo One',
                                        fontSize: 24,
                                        letterSpacing: 0.15000000596046448,
                                        fontWeight: FontWeight.w500,
                                        height: 1.5 /*PERCENT not supported*/
                                    ),),
                                  Text('Zone', textAlign: TextAlign.center, style: TextStyle(
                                      color: myColor,
                                      fontFamily: 'Russo One',
                                      fontSize: 20
                                      ,
                                      letterSpacing: 0.15000000596046448,
                                      fontWeight: FontWeight.w500,
                                      height: 1.5 /*PERCENT not supported*/
                                  ),)
                                  ],
                                ),

                                )
                              ],
                            ),
                            SizedBox(height: 20,),
                            Row(
                              children: [
                                SizedBox(
                                  width: 14,
                                ),
                                InkWell(
                                  onTap: (){
                                    Navigator.push(context, MaterialPageRoute(builder: (context)=>page3()));
                                  },
                                  child: Container(
                                    height: 160,
                                    width: 160,
                                    decoration: BoxDecoration(

                                        borderRadius: BorderRadius.circular(10),
                                        border:
                                        Border.all(color: myColor, width: 2)),



                                    child: Column(
                                      children: [
                                        SizedBox(height: 35,),
                                    Text('Middle', textAlign: TextAlign.center, style: TextStyle(
                                    color: myColor,
                                        fontFamily: 'Russo One',
                                        fontSize: 24,
                                        letterSpacing: 0.15000000596046448,
                                        fontWeight: FontWeight.w500,
                                        height: 1.5 /*PERCENT not supported*/
                                    ),),
                                    Text('Zone', textAlign: TextAlign.center, style: TextStyle(
                                        color: myColor,
                                        fontFamily: 'Russo One',
                                        fontSize: 20,
                                        letterSpacing: 0.15000000596046448,
                                        fontWeight: FontWeight.w500,
                                        height: 1.5 /*PERCENT not supported*/
                                    ),)
                                      ],
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  width: 15,
                                ),
                               Container(
                                      height: 160,
                                      width: 160,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        border:
                                        Border.all(color: myColor, width: 2),
                                      ),
                                  child:   Column(
                                    children: [
                                      SizedBox(height: 35,),
                                      Text('Eastern', textAlign: TextAlign.center, style: TextStyle(
                                          color: myColor,
                                          fontFamily: 'Russo One',
                                          fontSize: 24,
                                          letterSpacing: 0.15000000596046448,
                                          fontWeight: FontWeight.w500,
                                          height: 1.5 /*PERCENT not supported*/
                                      ),),
                                    Text('Zone', textAlign: TextAlign.center, style: TextStyle(
                                        color: myColor,
                                        fontFamily: 'Russo One',
                                        fontSize: 20,
                                        letterSpacing: 0.15000000596046448,
                                        fontWeight: FontWeight.w500,
                                        height: 1.5 /*PERCENT not supported*/
                                    ),)
                                    ],
                                  ),

                                  ),

                              ],

                            )


                          ],
                        )
                      ],
                    )))));
  }
}
