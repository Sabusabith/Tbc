import 'package:flutter/material.dart';
import 'package:qhance_uiii/Screens/page5.dart';
import 'package:qhance_uiii/widgets/textfield_widget.dart';

class page4 extends StatefulWidget {
  const page4({super.key});

  @override
  State<page4> createState() => _page4State();
}

class _page4State extends State<page4> {
  @override
  Widget build(BuildContext context) {
    Color myColor = Color(0xFF3EB489);
    return SafeArea(
      child: Scaffold(
        body: Column(
          children: [
            SizedBox(
              height: 18,
            ),
            Row(
              children: [
                SizedBox(
                  width: 5,
                ),
                Icon(
                  Icons.arrow_back,
                  size: 30,
                  color: myColor,
                ),
                SizedBox(
                  width: 68,
                ),
                Text(
                  "Add User",
                  style: TextStyle(
                    fontSize: 35,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                SizedBox(
                  width: 60,
                ),
                Icon(
                  Icons.logout,
                  size: 30,
                  color: myColor,
                ),
              ],
            ),
            SizedBox(
              height: 5,
            ),
            Text(
              "Fill the information in below field!!!",
              style: TextStyle(
                  fontWeight: FontWeight.w500,
                  fontSize: 17,
                  color: Colors.grey),
            ),
            SizedBox(height: 10,),





            Padding(
              padding: const EdgeInsets.all(5.0),
              child: texttfield(
                  horizontal: 14, hintText: "username", verticle: 15),
            ),  SizedBox(height: 6,),
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: texttfield(
                  horizontal: 14, hintText: "Password", verticle: 14),
            ),SizedBox(height: 6,),
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: texttfield(
                  horizontal: 14, hintText: "confirm Password", verticle: 14),
            ),SizedBox(height: 6,),
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: texttfield(
                  horizontal: 14, hintText: "Team code", verticle: 14),
            ),SizedBox(height: 6,),
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: texttfield(horizontal: 14, hintText: "Name", verticle: 14),
            ),SizedBox(height: 6,),
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: texttfield(
                  horizontal: 14, hintText: "Specialization", verticle: 14),
            ),SizedBox(height: 6,),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: texttfield(
                  horizontal: 14, hintText: "Phonenumber", verticle: 14),
            ),





            SizedBox(
              height: 30,
            ),
            InkWell(
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>page5()));
              },
              child: Container(
                width: 210,
                height: 57,
                decoration: BoxDecoration(
                  color: myColor,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(10),
                    topRight: Radius.circular(10),
                    bottomLeft: Radius.circular(10),
                    bottomRight: Radius.circular(10),
                  ),
                  boxShadow: [
                    BoxShadow(
                        color: Color.fromRGBO(0, 0, 0, 0.20000000298023224),
                        offset: Offset(0, 3),
                        blurRadius: 3)
                  ],
                ),
                child: Column(
                  children: [
                    SizedBox(
                      height: 7,
                    ),
                    Text(
                      "Register",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.w500,
                          color: Colors.white),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
