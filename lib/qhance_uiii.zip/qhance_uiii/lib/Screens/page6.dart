import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:qhance_uiii/Screens/page7.dart';
import 'package:qhance_uiii/Screens/page8.dart';
import 'package:qhance_uiii/widgets/elevatedbutton.dart';
import 'package:qhance_uiii/widgets/textfield_widget.dart';

class page6 extends StatefulWidget {
  const page6({super.key});

  @override
  State<page6> createState() => _page6State();
}

class _page6State extends State<page6> {
  @override
  Widget build(BuildContext context) {
    Color myColor = Color(0xFF3EB489);
    return Scaffold(
        body: SingleChildScrollView(
            child: Container(
                width: 500,
                height: 900,
                color: Colors.white,
                child: Column(children: [
                  Container(
                    width: 375,
                    height: 200,
                    decoration: BoxDecoration(
                      color: myColor,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(0),
                        topRight: Radius.circular(0),
                        bottomLeft: Radius.circular(110),
                        bottomRight: Radius.circular(110),
                      ),
                    ),
                    child: Container(
                        width: 35,
                        height: 27,
                        child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Stack(children: <Widget>[
                              Column(children: [
                                SizedBox(
                                  height: 30,
                                ),
                                Row(children: [
                                  Positioned(
                                      top: 2.25,
                                      left: 4.375,
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Icon(
                                          Icons.menu,
                                          color: Colors.white,
                                          size: 34,
                                        ),
                                      )),
                                  SizedBox(
                                    width: 260,
                                  ),
                                  Icon(
                                    Icons.logout,
                                    color: Colors.white,
                                    size: 27,
                                  ),
                                ]),
                                Text(
                                  "Item",
                                  style: GoogleFonts.inder(
                                      textStyle: TextStyle(fontSize: 30),
                                      fontWeight: FontWeight.w600,
                                      color: Colors.white),
                                ),
                              ])
                            ]))),
                  ),
                  SizedBox(
                    height: 35,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Container(
                      width: 320,
                      height: 100,
                      child: TextField(
                        decoration: InputDecoration(
                          contentPadding: EdgeInsets.symmetric(vertical: 80, horizontal: 18),
                          hintText: "What evidence do you need?",
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.blue, width: 2),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: myColor, width: 2),
                          ),
                        ),
                        textAlign: TextAlign.start,
                        maxLength: 300,
                        keyboardType: TextInputType.text,
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  Row(
                    children: [
                      SizedBox(
                        width: 40,
                      ),
                      Text(
                        "Action plan",
                        style: TextStyle(
                            fontWeight: FontWeight.w600,
                            color: Colors.black,
                            fontSize: 19),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Container(
                      width: 320,
                      height: 200,
                      child: TextField(
                        decoration: InputDecoration(
                          contentPadding: EdgeInsets.symmetric(vertical: 220, horizontal: 20),
                          hintText: "What evidence do you need?",
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.blue, width: 2),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: myColor, width: 2),
                          ),
                        ),
                        textAlign: TextAlign.start,
                        maxLength: 300,
                        keyboardType: TextInputType.text,
                      ),
                    ),
                  ),



                  SizedBox(
                    height: 30,
                  ),
                  InkWell(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>page7()));
                      },
                      child: Container(width: 300,height: 200,color: Colors.white,))
    ]),),
    )
    );
  }
}
