import 'package:flutter/material.dart';
import 'package:qhance_uiii/Screens/page4.dart';

import '../widgets/container_widget.dart';

class page3 extends StatefulWidget {
  const page3({super.key});

  @override
  State<page3> createState() => _page3State();
}

class _page3State extends State<page3> {
  @override
  Widget build(BuildContext context) {
    Color myColor = Color(0xFF3EB489);
    return SafeArea(
      child: Scaffold(
          body: Stack(children: [
        Container(
          width: 360,
          height: 850,
          color: myColor,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  children: [
                    SizedBox(
                      height: 9,
                    ),
                    Icon(
                      Icons.arrow_back,
                      color: Colors.white,
                      size: 27,
                    ),
                    SizedBox(
                      width: 17,
                    ),
                    Text(
                      ' Primary Health[Middle Zone]',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Color.fromRGBO(255, 255, 255, 1),
                          fontFamily: 'Inria Sans',
                          fontSize: 19,
                          letterSpacing: 0.15000000596046448,
                          fontWeight: FontWeight.bold,
                          height: 1.5 /*PERCENT not supported*/
                          ),
                    ),
                    SizedBox(
                      width: 18,
                    ),
                    Icon(
                      Icons.logout,
                      color: Colors.white,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        Positioned(
            //white Container
            top: 75,
            bottom: 0,
            child: Container(
              width: 360,
              height: 179,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(35),
                  topRight: Radius.circular(35),
                  bottomLeft: Radius.circular(0),
                  bottomRight: Radius.circular(0),
                ),
              ),
              child: Column(
                children: [
                  SizedBox(
                    height: 40,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: InkWell(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>page4()));
                      },
                      child: customcontainer(
                        text3: "care code",
                        borderRadius: 10,
                        Bordercolor: Colors.deepOrange,
                        text1: "Health Zone Name",
                        textColor: Colors.black87,
                        width: 320,
                        height: 80,
                        text: "Primary Health Care Name",
                        text1Color: Colors.grey,
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  customcontainer(
                      text3: "care code",
                      borderRadius: 10,
                      Bordercolor: Colors.black,
                      text: "Primary Health Care Name",
                      text1: "Health Zone Name",
                      textColor: Colors.black,
                      text1Color: Colors.grey,
                      width: 320,
                      height: 80),
                  SizedBox(
                    height: 20,
                  ),
                  customcontainer(
                      borderRadius: 10,
                      Bordercolor: Colors.black87,
                      text: "Primary Health Care Name",
                      text1: "Health Zone Name",
                      textColor: Colors.black87,
                      text1Color: Colors.grey,
                      width: 320,
                      height: 80, text3: "care code"),
                  SizedBox(
                    height: 20,
                  ),
                  customcontainer(
                    text3: "care code",
                      borderRadius: 10,
                      Bordercolor: Colors.black,
                      text: "Primary Health Care Name",
                      text1: "Health Zone Name",
                      textColor: Colors.black,
                      text1Color: Colors.grey,
                      width: 320,
                      height: 80),
                  SizedBox(
                    height: 20,
                  ),
                  customcontainer(
                    text3: "care code",
                      borderRadius: 10,
                      Bordercolor: Colors.white,
                      text: "Primary Health Care Name",
                      text1: "Health Zone Name",
                      textColor: Colors.black,
                      text1Color: Colors.grey,
                      width: 320,
                      height: 80)
                ],
              ),
            ))
      ])),
    );
  }
}
